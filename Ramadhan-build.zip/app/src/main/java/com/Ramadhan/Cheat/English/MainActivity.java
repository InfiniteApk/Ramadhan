package com.Ramadhan.Cheat.English;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private CheckBox checkbox9;
	private CheckBox checkbox13;
	private CheckBox checkbox1;
	private CheckBox checkbox2;
	private CheckBox checkbox4;
	private CheckBox checkbox11;
	private CheckBox checkbox5;
	private CheckBox checkbox6;
	private CheckBox checkbox12;
	private CheckBox checkbox8;
	private CheckBox checkbox7;
	private TextView textview2;
	private SeekBar seekbar1;
	private EditText edittext1;
	private EditText edittext2;
	private Button button1;
	private TextView textview3;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview7;
	
	private SharedPreferences save;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		checkbox9 = findViewById(R.id.checkbox9);
		checkbox13 = findViewById(R.id.checkbox13);
		checkbox1 = findViewById(R.id.checkbox1);
		checkbox2 = findViewById(R.id.checkbox2);
		checkbox4 = findViewById(R.id.checkbox4);
		checkbox11 = findViewById(R.id.checkbox11);
		checkbox5 = findViewById(R.id.checkbox5);
		checkbox6 = findViewById(R.id.checkbox6);
		checkbox12 = findViewById(R.id.checkbox12);
		checkbox8 = findViewById(R.id.checkbox8);
		checkbox7 = findViewById(R.id.checkbox7);
		textview2 = findViewById(R.id.textview2);
		seekbar1 = findViewById(R.id.seekbar1);
		edittext1 = findViewById(R.id.edittext1);
		edittext2 = findViewById(R.id.edittext2);
		button1 = findViewById(R.id.button1);
		textview3 = findViewById(R.id.textview3);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview7 = findViewById(R.id.textview7);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		checkbox9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		checkbox9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		checkbox7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					save.edit().putString("d", "s").commit();
				}
				else {
					
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Hack!");
			}
		});
	}
	
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		checkbox7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		edittext2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sobiscuit.ttf"), 3);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}